#include <Python.h>

#include "license.h"

struct module_state {
    PyObject *error;
};

#define GETSTATE(m) ((struct module_state*)PyModule_GetState(m))

static PyObject *
utils_is_signature_valid(PyObject *self, PyObject *args) {
    const char *data, *signature;

    if (!PyArg_ParseTuple(args, "ss", &data, &signature))
        return NULL;

    std::string dataStr(data), signatureStr(signature);

    try {
        bool result = LLUtil::isNoptixTextSignatureMatch(dataStr, signatureStr);

        return Py_BuildValue("i", result);
    } catch (const std::exception& e) {
        PyErr_SetString(PyExc_ValueError, e.what());
        return NULL;
    }
}

static PyObject *
utils_sign(PyObject *self, PyObject *args) {
    const char *data, *privateKey;

    if (!PyArg_ParseTuple(args, "ss", &data, &privateKey))
        return NULL;

    std::string dataStr(data), keyStr(privateKey);

    try {
        std::string signatureStr = LLUtil::sign(dataStr, keyStr);

        return Py_BuildValue("s", signatureStr.c_str());
    } catch (const std::exception& e) {
        PyErr_SetString(PyExc_ValueError, e.what());
        return NULL;
    }
}

static PyMethodDef llutil_methods[] = {
    {"is_signature_valid", utils_is_signature_valid, METH_VARARGS, "Verify signature"},
    {"sign", utils_sign, METH_VARARGS, "Sign message"},
    {NULL, NULL}
};

static int llutil_traverse(PyObject *m, visitproc visit, void *arg) {
    Py_VISIT(GETSTATE(m)->error);
    return 0;
}

static int llutil_clear(PyObject *m) {
    Py_CLEAR(GETSTATE(m)->error);
    return 0;
}


static struct PyModuleDef moduledef = {
        PyModuleDef_HEAD_INIT,
        "llutil",
        NULL,
        sizeof(struct module_state),
        llutil_methods,
        NULL,
        llutil_traverse,
        llutil_clear,
        NULL
};

PyMODINIT_FUNC
PyInit_llutil(void)
{
	PyObject *module = PyModule_Create(&moduledef);

	if (module == NULL)
        return NULL;

    struct module_state *st = GETSTATE(module);

    st->error = PyErr_NewException("llutil.Error", NULL, NULL);
    if (st->error == NULL) {
        Py_DECREF(module);
        return NULL;
    }

    return module;
}
