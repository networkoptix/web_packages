import sys, os, fnmatch, platform, argparse, shutil
from os.path import dirname, join, exists
from setuptools import setup, Extension
import shutil

module_name = 'llutil'
module_version = '0.6'
extra_compile_args = []

def platform():
    if sys.platform == 'darwin':
        return 'macosx'
    else:
        return sys.platform

if platform() == 'linux':
    os.environ['CC'] = 'g++'
    define_macros = []
    libraries = ['crypto']
    extra_link_args = []
elif sys.platform == 'darwin':
    os.environ['CC'] = 'g++'
    define_macros = []
    libraries = ['crypto']
    extra_compile_args = ['-Wno-error=unused-command-line-argument-hard-error-in-future']
    extra_link_args = ['-framework', 'IOKit']   

mod = Extension(module_name, 
    sources = ['llutil.cpp', 'license.cpp', 'base64.cpp'],
    libraries = libraries,
    define_macros = define_macros, 
    extra_compile_args = extra_compile_args,
    extra_link_args = extra_link_args)        

setup (name=module_name,
       version=module_version,
       description="Low-Level utilities.",
       license="Commercial",
       long_description="""\
Low-Level utilities from Network Optix HDWitness software
""",
       author='Ivan Vigasin',
       author_email='ivigasin@networkoptix.com',
       url='http://networkoptix.com',
       classifiers=[
    'Development Status :: 4 - Beta',
    'Intended Audience :: Developers',
    'License :: Commercial',
    'Topic :: System :: Utilities',
    ],
       ext_modules=[mod])    

