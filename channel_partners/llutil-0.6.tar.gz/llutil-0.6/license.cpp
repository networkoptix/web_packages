#include <string>
#include <cstring>

#include <openssl/rsa.h>
#include <openssl/pem.h>
#include <openssl/bio.h>
#include <openssl/err.h>
#include <openssl/sha.h>

#include "base64.h"
#include "license.h" 

static const char* nxRSAPublicKey = "-----BEGIN PUBLIC KEY-----\n"
    "MFwwDQYJKoZIhvcNAQEBBQADSwAwSAJBAN4wCk8ISwRsPH0Ev/ljnEygpL9n7PhA\n"
    "EwVi0AB6ht0hQ3sZUtM9UAGrszPJOzFfZlDB2hZ4HFyXfVZcbPxOdmECAwEAAQ==\n"
    "-----END PUBLIC KEY-----";

// This key is introduced in v2.3 to make new license types do not work in v2.2 and earlier
static const char* nxRSAPublicKey2 = "-----BEGIN PUBLIC KEY-----\n"
    "MFwwDQYJKoZIhvcNAQEBBQADSwAwSAJBALiqxgrnU2hl+8DVzgXrj6u4V+5ksnR5\n"
    "vtLsDeNC9eU2aLCt0Ba4KLnuVnDDWSXQ9914i8s0KXXTM+GOHpvrChUCAwEAAQ==\n"
    "-----END PUBLIC KEY-----";

// This key is introduced in v2.4 to make iomodule and starter license types do not work in v2.3 and earlier
static const char* nxRSAPublicKey3 = "-----BEGIN PUBLIC KEY-----\n"
    "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAtb16Q2sJL/eZqNpfItB0\n"
    "oMdhttY9Ov21QN8PedcJm8+1t/qjVBg2c1AxJsMnX+0MH4dcbC9W2JCU+e2vMCX7\n"
    "HMUW4gpmvRtHPDhNutgyByOVJ7TXzCrHR/5xCXojiOLISdikVyP+IDYP+ATe5mM5\n"
    "GIWG1uTTaG7gwwJn2IVggBzUapRWAm3VZUpytfPaLzqucc/zuvoMSUD5K9DZqg4p\n"
    "Meu8VWFCPA7VhFKyuTtdTjrj/72WpLdlcSbARYjjqOO51KUIESXrGUEiw1Mo0OOn\n"
    "acOz/C4G+lXfFDOALsYUNeG//UibSsfLPghvcIXdC7ghMtYBIzafA/UVcQOqZWPK\n"
    "6wIDAQAB\n"
    "-----END PUBLIC KEY-----";

namespace LLUtil {

bool isSignatureMatch(const std::string &data, const std::string& signature, const std::string &publicKey) {
    unsigned char dataHash[SHA_DIGEST_LENGTH];

    SHA1((const unsigned char*)data.data(), data.size(), dataHash);

    // Load RSA public key
    BIO *bp = BIO_new_mem_buf(const_cast<char *>(publicKey.data()), (int)publicKey.size());
    RSA* publicRSAKey = PEM_read_bio_RSA_PUBKEY(bp, 0, 0, 0);
    BIO_free(bp);

    if (publicRSAKey == 0 || signature.size() != RSA_size(publicRSAKey))
        return false;

    // Decrypt data
    std::string decrypted;
    decrypted.resize(signature.size());

    int ret = RSA_public_decrypt((int)signature.size(), (const unsigned char*)signature.data(), (unsigned char*)decrypted.data(), publicRSAKey, RSA_PKCS1_PADDING);
    RSA_free(publicRSAKey);

    // Verify signature is correct
    return std::memcmp(decrypted.data(), dataHash, ret) == 0;
}

std::string sign(const std::string &data, const std::string &privateKey) {
    unsigned char dataHash[SHA_DIGEST_LENGTH];

    SHA1((const unsigned char*)data.data(), data.size(), dataHash);    

    // Load RSA private key
    BIO *bp = BIO_new_mem_buf(const_cast<char *>(privateKey.data()), (int)privateKey.size());
    RSA* rsa = PEM_read_bio_RSAPrivateKey(bp, 0, 0, 0);
    BIO_free(bp);

    // Encrypt data
    std::string signature;
    signature.resize(RSA_size(rsa));

    int ret = RSA_private_encrypt(SHA_DIGEST_LENGTH, dataHash, (unsigned char*)signature.data(), rsa, RSA_PKCS1_PADDING);
    RSA_free(rsa);

    return base64_encode(signature);
}

bool isNoptixTextSignatureMatch(const std::string &data, const std::string &signature) {
    std::string binarySig = base64_decode(signature);

    return isSignatureMatch(data, binarySig, nxRSAPublicKey) ||
			isSignatureMatch(data, binarySig, nxRSAPublicKey2) ||
			isSignatureMatch(data, binarySig, nxRSAPublicKey3);
}

}
